SELECT Id, ShipCountry, 
CASE 
WHEN ShipCountry IS 'USA' THEN 'NorthAmerica' 
WHEN ShipCountry IS 'Mexico' THEN 'NorthAmerica' 
WHEN ShipCountry IS 'Canada' THEN 'NorthAmerica' 
ELSE 'OtherPlace' 
END 
FROM 'Order' 
WHERE Id > 15444 
ORDER BY Id ASC 
LIMIT 20;