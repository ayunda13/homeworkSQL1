SELECT CategoryName, COUNT(*) AS jml, ROUND(AVG(UnitPrice), 2) AS rataHarga, MIN(UnitPrice) AS hargaMin, MAX(UnitPrice) AS hargaMax, SUM(UnitsOnOrder) AS totalOrder
FROM Product INNER JOIN Category on CategoryId = Category.Id
GROUP BY CategoryId
HAVING jml > 10
ORDER BY CategoryId;