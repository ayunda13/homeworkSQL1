SELECT CompanyName, round(jmlTelat * 100.0 / jml, 2) AS persentase 
FROM (SELECT ShipVia, COUNT(*) AS jmlTelat 
      FROM 'Order'
      WHERE RequiredDate < ShippedDate 
      GROUP BY ShipVia) AS jmlTelat 
INNER JOIN (SELECT ShipVia, COUNT(*) AS jml 
            FROM 'Order' GROUP BY ShipVia) AS jml
ON jmlTelat.ShipVia = jml.ShipVia
INNER JOIN Shipper ON jmlTelat.ShipVia = Shipper.Id
ORDER BY persentase DESC;