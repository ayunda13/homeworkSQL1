SELECT RegionDescription, FirstName, LastName, ultah
FROM (SELECT RegionId AS idRegion, MAX(Employee.Birthdate) AS ultah FROM Employee
    INNER JOIN EmployeeTerritory ON Employee.Id = EmployeeTerritory.EmployeeId
    INNER JOIN Territory ON TerritoryId = Territory.Id GROUP BY RegionId)
INNER JOIN (SELECT FirstName, LastName, Birthdate, RegionId, EmployeeId FROM Employee
            INNER JOIN EmployeeTerritory ON Employee.Id = EmployeeTerritory.EmployeeId
            INNER JOIN Territory ON TerritoryId = Territory.Id)
           ON idRegion = RegionId AND Birthdate = ultah
INNER JOIN Region ON Region.Id = RegionId
GROUP BY EmployeeId
ORDER BY idRegion;