SELECT namaProduk, CompanyName, ContactName
FROM (SELECT namaProduk , min(OrderDate), CompanyName, ContactName
      FROM (SELECT Id AS idProduk, ProductName AS namaProduk  
            FROM Product WHERE Discontinued == 1) AS tidakTersedia
      INNER JOIN Customer ON CustomerId = Customer.Id
      INNER JOIN 'Order' ON 'Order'.Id = OrderDetail.OrderId
      INNER JOIN OrderDetail ON ProductId = idProduk 
      GROUP BY idProduk)
ORDER BY namaProduk  ASC;