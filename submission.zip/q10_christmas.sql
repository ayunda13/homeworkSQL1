SELECT GROUP_CONCAT(ProductName, ',') AS ProductCombined FROM Product 
INNER JOIN 'Order' ON 'Order'.Id = OrderDetail.OrderId
INNER JOIN Customer ON CustomerId = Customer.Id
INNER JOIN OrderDetail ON Product.Id = OrderDetail.ProductId 
WHERE DATE(OrderDate) = '2014-12-25' and CompanyName = 'Queen Cozinha' ORDER BY Product.Id ASC;