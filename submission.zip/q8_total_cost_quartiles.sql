WITH expenditures AS (SELECT IFNULL(Customer.CompanyName, 'MISSING_NAME') AS CompanyName, 'Order'.CustomerId, 
    ROUND(SUM(OrderDetail.Quantity * OrderDetail.UnitPrice), 2) AS TotalCost
    FROM 'Order' INNER JOIN OrderDetail ON OrderDetail.OrderId = 'Order'.Id LEFT JOIN Customer ON Customer.Id = 'Order'.CustomerId
    GROUP BY 'Order'.CustomerId), quartiles AS (SELECT *, NTILE(4) OVER (ORDER BY TotalCost ASC) AS ExpenditureQuartile FROM expenditures)
SELECT CompanyName, CustomerId, TotalCost
FROM quartiles
WHERE ExpenditureQuartile = 1
ORDER BY TotalCost ASC;