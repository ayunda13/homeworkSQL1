SELECT Id, OrderDate, tanggalOrderSebelumnya, ROUND(julianday(OrderDate) - julianday(tanggalOrderSebelumnya), 2) AS JulianDay
FROM (SELECT Id, OrderDate, LAG(OrderDate, 1, OrderDate) OVER (ORDER BY OrderDate ASC) AS tanggalOrderSebelumnya 
     FROM 'Order' 
     WHERE CustomerId LIKE '%BLONP%'
     ORDER BY OrderDate ASC
     LIMIT 10);